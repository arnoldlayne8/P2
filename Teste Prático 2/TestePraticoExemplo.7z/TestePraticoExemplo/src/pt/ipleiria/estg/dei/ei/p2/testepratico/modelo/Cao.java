package pt.ipleiria.estg.dei.ei.p2.testepratico.modelo;

public class Cao extends Utente {
    public Cao(String nome) {
        super(nome);
    }
}
