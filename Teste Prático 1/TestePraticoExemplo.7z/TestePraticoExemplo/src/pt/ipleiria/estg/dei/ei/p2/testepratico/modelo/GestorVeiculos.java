package pt.ipleiria.estg.dei.ei.p2.testepratico.modelo;

import java.util.LinkedList;

public enum GestorVeiculos {
    INSTANCIA;

    private LinkedList<Reboque> reboques;
    private LinkedList<Automovel> automoveis;
    private LinkedList<Barco> barcos;

    GestorVeiculos() {
        reboques = new LinkedList<>();
        automoveis = new LinkedList<>();
        barcos = new LinkedList<>();

        // TODO: Adicionar veículos
    }

    public LinkedList<Reboque> getReboques() {
        return new LinkedList<>(reboques);
    }

    public LinkedList<Automovel> getAutomoveis() {
        return new LinkedList<>(automoveis);
    }

    public LinkedList<Barco> getBarcos() {
        return new LinkedList<>(barcos);
    }
}
