package pt.ipleiria.estg.dei.ei.p2.testepratico.modelo;

public class Barco {

}