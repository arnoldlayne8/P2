package pt.ipleiria.estg.dei.ei.p2.testepratico.modelo;

public class Pessoa extends Utente {
    public Pessoa(String nome) {
        super(nome);
    }
}
